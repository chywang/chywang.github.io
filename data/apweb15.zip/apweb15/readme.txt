Taxonomy generated based on paper “User Generated Content Oriented Chinese Taxonomy Construction”

###################### data format ######################id \t entity1 \t relation \t entity2

####################### dataset size #######################

Please refer to the paper for details.
