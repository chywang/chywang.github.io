
###################### data format ######################noun compound \t labellabel = 1 transparantlabel = 2 partly opaque
label = 3 partly idiomatic
label = 4 completely idiomatic

####################### dataset size #######################

total: 1330

####################### announcement #######################

The noun compounds are sampled from  entity names and categories http://baike.baidu.com/.
The labels (1, 2, 3 or 4) are added by multiple human annotators.
We try our best to make the labels correct. 
However, due to the ambiguity of the natural language, there is no guarantee that the labels are 100% correct for everyone.