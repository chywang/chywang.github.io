Readme for the software in paper “HEEL: Exploratory Entity Linking for Heterogeneous Information Networks”

############################### comment to reviewers ###############################

Dear Reviewers,

This project includes codes of the PC-EM algorithm, a JAR application for exploratory author name linking on the fly and test cases. It is used for reviewers to validate our research. In the future, we will release more resources.

Regards,
Authors 

###################### application ######################

The hin.jar file is generated in the JavaSE 1.8 environment. If it is not executable in your system, you can generate the JAR file from the source codes by yourself.

We take papers from Hui Fang as test cases, downloaded from the DBLP website and processed according the methods described in the paper. The program can perform exploratory author linking over Hui Fang’s papers. The input file is input.txt, containing a collection of papers authored by Hui Fang. The script can be found in script.txt. After running the script, unlinked papers will be linked to one of the authors named Hui Fang, or new authors.

Existing authors: Hui Fang 0001, Hui Fang 0002, etc.
New authors: Hui Fang 00001, Hui Fang 00002, etc.

Note that this is a preliminary version of the entire project. Because the DBLP HIN is too large, we run PC-EM on a tiny ``HIN’’ constructed based on input.txt in the released version. Thus the results may be different from those reported in the paper. You can also modify the parameters in the source codes.


