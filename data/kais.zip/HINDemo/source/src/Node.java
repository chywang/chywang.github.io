
public class Node {

	public int id;
	public String name;
	public NodeType type;

	public Node(int id, String name, NodeType type) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
	}

}
