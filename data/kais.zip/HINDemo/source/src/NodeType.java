
public enum NodeType {

	PAPER, AUTHOR, YEAR, VENUE, TERM

}
