###################### data format ######################

Each relation instance is written in one line, with the format:word1 \t word2

############################## dataset description ##############################

This collection of datasets contain hypernymy and non-hypernymy relations of seven lower-resourced languages generated from Open Multilingual Wordnet. Refer to the statistics in the paper.