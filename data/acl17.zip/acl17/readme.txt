Readme for dataset in paper “Transductive Non-linear Learning for Chinese Hypernym Prediction”

###################### data format ######################word1 \t word2 \t labellabel = 1 word2 is a hypernym of word1.label = 0 otherwise.

####################### dataset size #######################

positive: 3870
negative: 3582
total: 7452

####################### announcement #######################

The words are crawled from http://baike.baidu.com/.
The labels (0 or 1) are added by multiple human annotators.
We try our best to make the labels correct. 
However, due to the ambiguity of the natural language, there is no guarantee that the labels are 100% correct for everyone.

